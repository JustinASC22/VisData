const projects = $(".projects")

$.ajax("../json/projects.json")
.then((data) =>{   
console.log(data)
data.forEach((project)=>{
    const div = $("<div class= 'project'>")
    div.html(`
    <h3>${project.title}<h3>
    <p>${project.description}</p>`)
    projects.append(div)
})
})